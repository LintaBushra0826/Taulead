import React, { useState, useEffect } from "react";
import axios from "axios";
import { Radio } from "antd";
import { Chart } from "./index.styled";

import { Task, ViewMode, Gantt } from "gantt-task-react-pro";
import ViewSwitcher from "./components/view-switcher";
import { getStartEndDateForProject, initTasks } from "./components/helper";
import "gantt-task-react/dist/index.css";

function ProcessChart() {
  const [size, setSize] = useState("Month");
  const [tasks, setTasks] = useState([]);
  const [view, setView] = useState(ViewMode.Day);
  const [isChecked, setIsChecked] = useState(true);

  useEffect(() => {
    fetchProcessData();
  }, []);

  const fetchProcessData = async () => {
    try {
      const response = await axios.get("http://localhost:3003/process");
      const subprocessResponse = await axios.get(
        "http://localhost:3003/subprocess"
      );
      const rawData = response.data.data;
      const subprocess = subprocessResponse.data.data;
      console.log("subprocess", subprocess);
      const tasks = [];
      let count = 1;

      const processData = rawData.forEach((item) => {
        setTasks([...tasks, {
          start: new Date(item.start),
          end: new Date(item.end),
          name: item.name,
          id: item._id,
          progress: 25,
          type: "project",
          hideChildren: false,
          displayOrder: count,
          subTasks: [],
        }]);
        count++;
        
        subprocess.forEach((subitem) => {
          const parentProcess = processData.find(
            (process) => process.name === subitem.pName
          );

          if (parentProcess) {
            const substartDate = new Date(subitem.substart);
            const subendDate = new Date(subitem.subend);

            setTasks([...tasks,{
              start: new Date(
              ),
              end: new Date(
              ),
              name: subitem.name,
              id: subitem._id,
              progress: 25,
              dependencies: [item._id],
              type: "task",
              project: "ProjectSample",
              displayOrder: count,
            }]);
            count++;
          }
        });
    
        console.log("processData", processData);
        console.log("Empty tasks", tasks);
      });
      // const startDate = new Date(item.start);
      // const endDate = new Date(item.end);

      // const year = startDate.getFullYear();
      // const month = startDate.getMonth();
      // const day = startDate.getDay();
      // // const hours = startDate.getHours();
      // // const minutes = startDate.getMinutes();
      // // const seconds = minutes * 60;
      // const endyear = endDate.getFullYear();
      // const endmonth = endDate.getMonth();
      // const endday = endDate.getDay();
      // // const endhours = endDate.getHours();
      // // const endminutes = endDate.getMinutes();
      // // const endseconds = endminutes * 60;

      // const strtdate = new Date(year, month, day);
      // const enddate = new Date(endyear, endmonth, endday);
      // // const starttime = `${hours}:${minutes}:${seconds}`;
      // // const endtime = `${endhours}:${endminutes}:${endseconds}`;

      //   return {
      //     ...item,
      //     strtdate,
      //     enddate,
      //     subTasks: [],
      //   };
      // });

      // Iterate through subprocesses and associate them with their parent tasks
      // subprocessResponse.data.data.forEach((subitem) => {
      //   const parentProcess = processedDataArray.find(
      //     (process) => process.name === subitem.pName
      //   );

      //   if (parentProcess) {
      //     const substartDate = new Date(subitem.substart);
      //     const subendDate = new Date(subitem.subend);

      //     // const subyear = substartDate.getFullYear();
      //     // const submonth = substartDate.getMonth();
      //     // const subday = substartDate.getDay();
      //     // // const hours = startDate.getHours();
      //     // // const minutes = startDate.getMinutes();
      //     // // const seconds = minutes * 60;
      //     // const subendyear = subendDate.getFullYear();
      //     // const subendmonth = subendDate.getMonth();
      //     // const subendday = subendDate.getDay();
      //     // // const endhours = endDate.getHours();
      //     // // const endminutes = endDate.getMinutes();
      //     // // const endseconds = endminutes * 60;

      //     // const substrtdate = new Date(subyear, submonth, subday);
      //     // const subenddate = new Date(subendyear, subendmonth, subendday);

      //     parentProcess.subTasks.push({
      //       ...subitem,
      //       // substrtdate,
      //       // subenddate,
      //       substartDate,
      //       subendDate,
      //     });
      //   }
      // });

      // setEmptyTasks(processedDataArray);
      // console.log("Final Process:", processedDataArray);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // const tasks = data
  //   ? data.map((item, subitem) => ({
  //       key: item._id,
  //       start: item.strtdate,
  //       end: item.enddate,
  //       name: item.name,
  //       duration: item.enddate - item.strtdate,
  //       type: "task",
  //       progress: 45,
  //       isDisabled: true,
  //       styles: {
  //         progressColor: "#F3904F",
  //         progressSelectedColor: "#F3904F",
  //       },
  //       dependencies: []
  //       // key:item.subTasks._id,
  //       // start:item.subTasks.substrtdate,
  //       // end: item.subTasks.enddate,
  //       // name: item.subTasks.subname,
  //       // duration: item.enddate - item.strtdate,
  //       // type: "task",

  //     }))
  //     // {
  //     //   key: subitem._id,
  //     //   dependencies: "6513b785ad3b5cc22bcaa660",
  //     //   start: subitem.substartDate,
  //     //   end: subitem.subendDate,
  //     //   name: subitem.subname,
  //     //   duration: subitem.subenddate - subitem.substrtdate,
  //     //   type: "subtask",
  //     //   progress: 45,
  //     //   isDisabled: true,
  //     //   styles: {
  //     //     progressColor: "#ffbb54",
  //     //     progressSelectedColor: "#ff9e0d",
  //     //   },
  //     // }
  //   : [];
  // const currentDate = new Date();

  // const tasks = [
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 1),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 15),
  //     name: "1",
  //     id: "ProjectSample",
  //     progress: 25,
  //     type: "project",
  //     hideChildren: false,
  //     displayOrder: 1,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 1),
  //     end: new Date(
  //       currentDate.getFullYear(),
  //       currentDate.getMonth(),
  //       2,
  //       12,
  //       28
  //     ),
  //     name: "Idea",
  //     id: "Task 0",
  //     progress: 45,
  //     type: "task",
  //     project: "ProjectSample",
  //     displayOrder: 2,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 2),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 4, 0, 0),
  //     name: "Research",
  //     id: "Task 1",
  //     progress: 25,
  //     dependencies: ["Task 0"],
  //     type: "task",
  //     project: "ProjectSample",
  //     displayOrder: 3,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 4),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 8, 0, 0),
  //     name: "Discussion with team",
  //     id: "Task 2",
  //     progress: 10,
  //     dependencies: ["Task 1"],
  //     type: "task",
  //     project: "ProjectSample",
  //     displayOrder: 4,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 8),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 9, 0, 0),
  //     name: "Developing",
  //     id: "Task 3",
  //     progress: 2,
  //     dependencies: ["Task 2"],
  //     type: "task",
  //     project: "ProjectSample",
  //     displayOrder: 5,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 8),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 10),
  //     name: "Review",
  //     id: "Task 4",
  //     type: "task",
  //     progress: 70,
  //     dependencies: ["Task 2"],
  //     project: "ProjectSample",
  //     displayOrder: 6,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 15),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 15),
  //     name: "Release",
  //     id: "Task 6",
  //     progress: currentDate.getMonth(),
  //     type: "milestone",
  //     dependencies: ["Task 4"],
  //     project: "ProjectSample",
  //     displayOrder: 7,
  //   },
  //   {
  //     start: new Date(currentDate.getFullYear(), currentDate.getMonth(), 18),
  //     end: new Date(currentDate.getFullYear(), currentDate.getMonth(), 19),
  //     name: "Party Time",
  //     id: "Task 9",
  //     progress: 0,
  //     isDisabled: true,
  //     type: "task",
  //   },
  // ];

  // const taskValues = {
  //   id: "key",
  //   name: "name",
  //   StartDate: "start",
  //   EndDate: "end",
  //   Duration: "duration",
  //   Progress: "progress",
  //   child: "subTasks",
  // };

  const onChange = (e) => {
    setSize(e.target.value);
  };

  let columnWidth = 65;
  if (view === ViewMode.Year) {
    columnWidth = 350;
  } else if (view === ViewMode.Month) {
    columnWidth = 300;
  } else if (view === ViewMode.Week) {
    columnWidth = 250;
  }

  const handleTaskChange = (task) => {
    console.log("On date change Id:" + task.id);
    let newTasks = tasks.map((t) => (t.id === task.id ? task : t));
    if (task.project) {
      const [start, end] = getStartEndDateForProject(newTasks, task.project);
      const project =
        newTasks[newTasks.findIndex((t) => t.id === task.project)];
      if (
        project.start.getTime() !== start.getTime() ||
        project.end.getTime() !== end.getTime()
      ) {
        const changedProject = { ...project, start, end };
        newTasks = newTasks.map((t) =>
          t.id === task.project ? changedProject : t
        );
      }
    }
    setTasks(newTasks);
  };

  const handleTaskDelete = (task) => {
    const conf = window.confirm("Are you sure about " + task.name + " ?");
    if (conf) {
      setTasks(tasks.filter((t) => t.id !== task.id));
    }
    return conf;
  };

  const handleProgressChange = async (task) => {
    setTasks(tasks.map((t) => (t.id === task.id ? task : t)));
    console.log("On progress change Id:" + task.id);
  };

  const handleDblClick = (task) => {
    alert("On Double Click event Id:" + task.id);
  };

  const handleClick = (task) => {
    console.log("On Click event Id:" + task.id);
  };

  const handleSelect = (task, isSelected) => {
    console.log(task.name + " has " + (isSelected ? "selected" : "unselected"));
  };

  const handleExpanderClick = (task) => {
    setTasks(tasks.map((t) => (t.id === task.id ? task : t)));
    console.log("On expander click Id:" + task.id);
  };

  return (
    <div className="Wrapper">
      <ViewSwitcher
        onViewModeChange={(viewMode) => setView(viewMode)}
        onViewListChange={setIsChecked}
        isChecked={isChecked}
      />
      <h3>Gantt With Unlimited Height</h3>

      {tasks.length > 0 ? (
        <Chart>
          <Gantt
            tasks={tasks}
            viewMode={view}
            onDateChange={handleTaskChange}
            onDelete={handleTaskDelete}
            onProgressChange={handleProgressChange}
            onDoubleClick={handleDblClick}
            onClick={handleClick}
            onSelect={handleSelect}
            onExpanderClick={handleExpanderClick}
            listCellWidth={isChecked ? "155px" : ""}
            columnWidth={columnWidth}
          />
        </Chart>
      ) : (
        <p>Loading data...</p>
      )}
    </div>
  );
}

export default ProcessChart;
